# DBA-Scripts
SQL Server Scripts for DBAs
