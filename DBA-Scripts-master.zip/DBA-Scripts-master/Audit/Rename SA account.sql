
ALTER LOGIN [sa] WITH NAME = [somethingobnoxiouslyhardtofigureout_dontuse_sa2]

